import { createContext, useState, useEffect, ReactNode } from 'react';

// Define the User type
export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

// Define the context type
interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

// Create context with default values
export const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => false,
  register: async () => false,
  logout: () => {},
});

// Provider component
export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check if user is already logged in on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('okpay_user');
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    
    setIsLoading(false);
  }, []);

  // Login function
  const login = async (email: string, password: string): Promise<boolean> => {
    // This would normally be an API call
    // For demo purposes, we'll simulate a successful login
    if (email && password) {
      const mockUser: User = {
        id: '1',
        name: 'Demo User',
        email: email,
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
      };
      
      setUser(mockUser);
      localStorage.setItem('okpay_user', JSON.stringify(mockUser));
      return true;
    }
    
    return false;
  };

  // Register function
  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    // This would normally be an API call
    // For demo purposes, we'll simulate a successful registration
    if (name && email && password) {
      const mockUser: User = {
        id: '1',
        name: name,
        email: email,
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
      };
      
      setUser(mockUser);
      localStorage.setItem('okpay_user', JSON.stringify(mockUser));
      return true;
    }
    
    return false;
  };

  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem('okpay_user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};