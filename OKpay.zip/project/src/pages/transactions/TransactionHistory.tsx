import { useState, useEffect } from 'react';
import { 
  Filter, 
  Download, 
  RefreshCw, 
  Calendar, 
  Search,
  ArrowUpDown,
  Loader
} from 'lucide-react';
import TransactionItem from '../../components/transactions/TransactionItem';

const TransactionHistory = () => {
  const [transactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [dateRange, setDateRange] = useState('all');
  
  useEffect(() => {
    // Simulating API call to fetch transactions
    const fetchTransactions = async () => {
      setIsLoading(true);
      
      // Mock data
      const mockTransactions = [
        {
          id: '1',
          type: 'received',
          amount: 350.00,
          description: 'Payment received',
          recipient: 'John Doe',
          date: '2025-04-10T10:30:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
        },
        {
          id: '2',
          type: 'sent',
          amount: 125.50,
          description: 'Monthly rent',
          recipient: 'Landlord Inc',
          date: '2025-04-08T14:20:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/women/44.jpg'
        },
        {
          id: '3',
          type: 'received',
          amount: 75.00,
          description: 'Refund',
          recipient: 'Online Store',
          date: '2025-04-05T09:15:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/men/67.jpg'
        },
        {
          id: '4',
          type: 'sent',
          amount: 42.99,
          description: 'Subscription payment',
          recipient: 'Streaming Service',
          date: '2025-04-02T11:45:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/women/29.jpg'
        },
        {
          id: '5',
          type: 'sent',
          amount: 18.50,
          description: 'Coffee shop',
          recipient: 'Café Express',
          date: '2025-03-28T08:30:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/men/54.jpg'
        },
        {
          id: '6',
          type: 'received',
          amount: 500.00,
          description: 'Salary payment',
          recipient: 'ABC Company',
          date: '2025-03-25T16:00:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/women/68.jpg'
        },
        {
          id: '7',
          type: 'sent',
          amount: 95.20,
          description: 'Grocery shopping',
          recipient: 'Supermarket Inc',
          date: '2025-03-22T12:15:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/men/41.jpg'
        },
        {
          id: '8',
          type: 'received',
          amount: 120.00,
          description: 'Reimbursement',
          recipient: 'Jane Smith',
          date: '2025-03-18T14:50:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/women/22.jpg'
        }
      ];
      
      // Simulate network delay
      setTimeout(() => {
        setTransactions(mockTransactions);
        setIsLoading(false);
      }, 1000);
    };
    
    fetchTransactions();
  }, []);
  
  // Filter transactions based on search term, type, and date range
  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = 
      transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.recipient.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = 
      filterType === 'all' || 
      (filterType === 'sent' && transaction.type === 'sent') ||
      (filterType === 'received' && transaction.type === 'received');
    
    // For a real app, implement proper date filtering based on dateRange
    // This is a simplified example
    return matchesSearch && matchesType;
  });
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Transaction History</h1>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 px-3 py-1.5 bg-white rounded-lg border border-gray-200">
            <Download size={16} />
            <span>Export</span>
          </button>
          
          <button className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 px-3 py-1.5">
            <RefreshCw size={16} />
            <span>Refresh</span>
          </button>
        </div>
      </div>
      
      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
            placeholder="Search transactions"
          />
        </div>
        
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <ArrowUpDown size={18} className="text-gray-400" />
          </div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 appearance-none"
          >
            <option value="all">All Transactions</option>
            <option value="sent">Money Sent</option>
            <option value="received">Money Received</option>
          </select>
        </div>
        
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Calendar size={18} className="text-gray-400" />
          </div>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 appearance-none"
          >
            <option value="all">All Time</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
          </select>
        </div>
      </div>
      
      {/* Transactions List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="grid grid-cols-4 gap-4 p-4 border-b border-gray-100 bg-gray-50 text-sm font-medium text-gray-500">
          <div className="col-span-2">Transaction</div>
          <div>Date</div>
          <div className="text-right">Amount</div>
        </div>
        
        <div className="divide-y divide-gray-100">
          {isLoading ? (
            <div className="flex justify-center items-center py-16">
              <Loader size={32} className="animate-spin text-blue-600" />
            </div>
          ) : filteredTransactions.length > 0 ? (
            filteredTransactions.map((transaction) => (
              <TransactionItem key={transaction.id} transaction={transaction} showDetails />
            ))
          ) : (
            <div className="p-8 text-center text-gray-500">
              <Filter size={40} className="mx-auto mb-4 text-gray-400" />
              <p className="font-medium">No transactions found</p>
              <p className="text-sm mt-1">Try adjusting your filters or search terms</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TransactionHistory;