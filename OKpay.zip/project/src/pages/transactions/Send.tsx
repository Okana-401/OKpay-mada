import { useState } from 'react';
import { 
  User, 
  DollarSign, 
  MessageSquare, 
  Send as SendIcon,
  Search,
  ChevronRight,
  Loader
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { formatCurrency } from '../../utils/formatters';

const Send = () => {
  const [step, setStep] = useState(1);
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedContact, setSelectedContact] = useState<any | null>(null);
  
  // Mock contacts
  const contacts = [
    { id: '1', name: 'John Doe', email: 'john@example.com', avatar: 'https://randomuser.me/api/portraits/men/32.jpg' },
    { id: '2', name: 'Jane Smith', email: 'jane@example.com', avatar: 'https://randomuser.me/api/portraits/women/44.jpg' },
    { id: '3', name: 'Bob Johnson', email: 'bob@example.com', avatar: 'https://randomuser.me/api/portraits/men/67.jpg' },
    { id: '4', name: 'Alice Brown', email: 'alice@example.com', avatar: 'https://randomuser.me/api/portraits/women/29.jpg' },
    { id: '5', name: 'Mark Wilson', email: 'mark@example.com', avatar: 'https://randomuser.me/api/portraits/men/76.jpg' },
    { id: '6', name: 'Sarah Davis', email: 'sarah@example.com', avatar: 'https://randomuser.me/api/portraits/women/81.jpg' },
  ];
  
  // Filter contacts by search term
  const filteredContacts = contacts.filter(contact => 
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    contact.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleSelectContact = (contact: any) => {
    setSelectedContact(contact);
    setRecipient(contact.email);
    setStep(2);
  };
  
  const handleContinue = () => {
    if (step === 2) {
      if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
        toast.error('Please enter a valid amount');
        return;
      }
      
      // In a real app, check if amount is greater than balance
      if (Number(amount) > 5000) {
        toast.error('Insufficient funds');
        return;
      }
      
      setStep(3);
    }
  };
  
  const handleSendMoney = () => {
    setIsProcessing(true);
    
    // Simulate API call
    setTimeout(() => {
      toast.success(`${formatCurrency(Number(amount))} sent to ${selectedContact?.name || recipient}`);
      setIsProcessing(false);
      setStep(1);
      setRecipient('');
      setAmount('');
      setNote('');
      setSelectedContact(null);
    }, 2000);
  };
  
  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Send Money</h1>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {/* Steps Progress */}
        <div className="p-4 bg-gray-50 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
              }`}>
                1
              </div>
              <div className={`h-1 w-12 mx-2 ${step > 1 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
              }`}>
                2
              </div>
              <div className={`h-1 w-12 mx-2 ${step > 2 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
              }`}>
                3
              </div>
            </div>
            
            <div className="text-sm text-gray-500">
              Step {step} of 3
            </div>
          </div>
        </div>
        
        <div className="p-6">
          {/* Step 1: Select Recipient */}
          {step === 1 && (
            <div>
              <h2 className="text-lg font-semibold mb-4">Select Recipient</h2>
              
              <div className="space-y-4">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Search by name or email"
                  />
                </div>
                
                <div className="mb-4">
                  <p className="text-sm text-gray-500 mb-2">Frequent Contacts</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {filteredContacts.slice(0, 4).map((contact) => (
                      <button
                        key={contact.id}
                        onClick={() => handleSelectContact(contact)}
                        className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                      >
                        <img
                          src={contact.avatar}
                          alt={contact.name}
                          className="w-10 h-10 rounded-full mr-3"
                        />
                        <div className="text-left">
                          <p className="font-medium">{contact.name}</p>
                          <p className="text-sm text-gray-500">{contact.email}</p>
                        </div>
                        <ChevronRight size={16} className="ml-auto text-gray-400" />
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="mb-4">
                  <p className="text-sm text-gray-500 mb-2">Or Enter Details Manually</p>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User size={18} className="text-gray-400" />
                    </div>
                    <input
                      type="text"
                      value={recipient}
                      onChange={(e) => setRecipient(e.target.value)}
                      className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Email or OkPay ID"
                    />
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <button
                    onClick={() => setStep(2)}
                    disabled={!recipient}
                    className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Continue
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 2: Enter Amount */}
          {step === 2 && (
            <div>
              <h2 className="text-lg font-semibold mb-4">Enter Amount</h2>
              
              {selectedContact && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg mb-4">
                  <img
                    src={selectedContact.avatar}
                    alt={selectedContact.name}
                    className="w-10 h-10 rounded-full mr-3"
                  />
                  <div>
                    <p className="font-medium">{selectedContact.name}</p>
                    <p className="text-sm text-gray-500">{selectedContact.email}</p>
                  </div>
                  <button 
                    onClick={() => {
                      setStep(1);
                      setSelectedContact(null);
                    }}
                    className="ml-auto text-blue-600 text-sm hover:text-blue-800"
                  >
                    Change
                  </button>
                </div>
              )}
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
                    Amount
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <DollarSign size={18} className="text-gray-400" />
                    </div>
                    <input
                      id="amount"
                      type="text"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-lg"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="note" className="block text-sm font-medium text-gray-700 mb-1">
                    Note (Optional)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <MessageSquare size={18} className="text-gray-400" />
                    </div>
                    <input
                      id="note"
                      type="text"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                      placeholder="What's this for?"
                    />
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-4">
                  <button
                    onClick={() => setStep(1)}
                    className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg"
                  >
                    Back
                  </button>
                  
                  <button
                    onClick={handleContinue}
                    disabled={!amount}
                    className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Continue
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 3: Confirm */}
          {step === 3 && (
            <div>
              <h2 className="text-lg font-semibold mb-4">Confirm Payment</h2>
              
              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <div className="flex flex-col items-center">
                  {selectedContact ? (
                    <img
                      src={selectedContact.avatar}
                      alt={selectedContact.name}
                      className="w-16 h-16 rounded-full mb-3"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-3">
                      <User size={24} className="text-blue-600" />
                    </div>
                  )}
                  
                  <p className="text-lg font-semibold">
                    {selectedContact ? selectedContact.name : recipient}
                  </p>
                  <p className="text-sm text-gray-500 mb-4">
                    {selectedContact ? selectedContact.email : recipient}
                  </p>
                  
                  <div className="text-3xl font-bold mb-2">
                    {formatCurrency(Number(amount))}
                  </div>
                  
                  {note && (
                    <p className="text-gray-600 italic">"{note}"</p>
                  )}
                </div>
              </div>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Amount</span>
                  <span className="font-medium">{formatCurrency(Number(amount))}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Fee</span>
                  <span className="font-medium">{formatCurrency(0)}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-gray-600 font-medium">Total</span>
                  <span className="font-bold">{formatCurrency(Number(amount))}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4">
                <button
                  onClick={() => setStep(2)}
                  className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg"
                  disabled={isProcessing}
                >
                  Back
                </button>
                
                <button
                  onClick={handleSendMoney}
                  disabled={isProcessing}
                  className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
                >
                  {isProcessing ? (
                    <>
                      <Loader size={18} className="animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <SendIcon size={18} />
                      <span>Send Money</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Send;