import { ArrowUpRight, ArrowDownRight, TrendingUp, DollarSign, RefreshCw } from 'lucide-react';
import { useEffect, useState } from 'react';
import QuickTransferCard from '../../components/dashboard/QuickTransferCard';
import TransactionItem from '../../components/transactions/TransactionItem';
import { formatCurrency } from '../../utils/formatters';

const Dashboard = () => {
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulating API call to fetch data
    const fetchData = async () => {
      setIsLoading(true);
      
      // Mock data
      const mockTransactions = [
        {
          id: '1',
          type: 'received',
          amount: 350.00,
          description: 'Payment received',
          recipient: 'John Doe',
          date: '2025-04-10T10:30:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
        },
        {
          id: '2',
          type: 'sent',
          amount: 125.50,
          description: 'Monthly rent',
          recipient: 'Landlord Inc',
          date: '2025-04-08T14:20:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/women/44.jpg'
        },
        {
          id: '3',
          type: 'received',
          amount: 75.00,
          description: 'Refund',
          recipient: 'Online Store',
          date: '2025-04-05T09:15:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/men/67.jpg'
        },
        {
          id: '4',
          type: 'sent',
          amount: 42.99,
          description: 'Subscription payment',
          recipient: 'Streaming Service',
          date: '2025-04-02T11:45:00Z',
          status: 'completed',
          avatar: 'https://randomuser.me/api/portraits/women/29.jpg'
        }
      ];
      
      setTimeout(() => {
        setRecentTransactions(mockTransactions);
        setIsLoading(false);
      }, 1000);
    };
    
    fetchData();
  }, []);
  
  // Mock contacts for quick transfer
  const contacts = [
    { id: '1', name: 'John Doe', email: 'john@example.com', avatar: 'https://randomuser.me/api/portraits/men/32.jpg' },
    { id: '2', name: 'Jane Smith', email: 'jane@example.com', avatar: 'https://randomuser.me/api/portraits/women/44.jpg' },
    { id: '3', name: 'Bob Johnson', email: 'bob@example.com', avatar: 'https://randomuser.me/api/portraits/men/67.jpg' },
    { id: '4', name: 'Alice Brown', email: 'alice@example.com', avatar: 'https://randomuser.me/api/portraits/women/29.jpg' },
  ];
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <button className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800">
          <RefreshCw size={16} />
          <span>Refresh</span>
        </button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Balance</p>
              <h3 className="text-2xl font-bold">{formatCurrency(5280.50)}</h3>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <DollarSign size={20} className="text-blue-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <TrendingUp size={16} className="text-green-500 mr-1" />
            <span className="text-green-500 font-medium">+12.5%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Income</p>
              <h3 className="text-2xl font-bold">{formatCurrency(2450.80)}</h3>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <ArrowDownRight size={20} className="text-green-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <TrendingUp size={16} className="text-green-500 mr-1" />
            <span className="text-green-500 font-medium">+8.2%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Expenses</p>
              <h3 className="text-2xl font-bold">{formatCurrency(1350.30)}</h3>
            </div>
            <div className="p-3 bg-red-100 rounded-lg">
              <ArrowUpRight size={20} className="text-red-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <TrendingUp size={16} className="text-red-500 mr-1" />
            <span className="text-red-500 font-medium">+4.1%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Savings</p>
              <h3 className="text-2xl font-bold">{formatCurrency(1100.20)}</h3>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <TrendingUp size={20} className="text-purple-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <TrendingUp size={16} className="text-green-500 mr-1" />
            <span className="text-green-500 font-medium">+15.3%</span>
            <span className="text-gray-500 ml-1">from last month</span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Recent Transactions</h2>
              <a href="/dashboard/transactions" className="text-sm text-blue-600 hover:text-blue-800">
                View All
              </a>
            </div>
          </div>
          
          <div className="divide-y divide-gray-100">
            {isLoading ? (
              <div className="p-6 flex justify-center">
                <div className="animate-pulse flex flex-col w-full space-y-4">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="flex items-center space-x-4">
                      <div className="rounded-full bg-gray-200 h-12 w-12"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                      <div className="h-5 bg-gray-200 rounded w-16"></div>
                    </div>
                  ))}
                </div>
              </div>
            ) : recentTransactions.length > 0 ? (
              recentTransactions.map((transaction) => (
                <TransactionItem key={transaction.id} transaction={transaction} />
              ))
            ) : (
              <div className="p-6 text-center text-gray-500">No transactions found</div>
            )}
          </div>
        </div>
        
        {/* Quick Transfer */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-lg font-semibold">Quick Transfer</h2>
          </div>
          
          <div className="p-6">
            <QuickTransferCard contacts={contacts} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;