import { useState } from 'react';
import { 
  PlusCircle, 
  ArrowDown, 
  CreditCard, 
  RefreshCw,
  DollarSign,
  Wallet as WalletIcon,
  Copy,
  CheckCircle
} from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import WalletCard from '../../components/wallet/WalletCard';
import { toast } from 'react-hot-toast';

const Wallet = () => {
  const [showAddFunds, setShowAddFunds] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  
  // Mock wallet data
  const wallet = {
    id: 'wallet_1234567890',
    balance: 5280.50,
    currency: 'USD',
    cards: [
      {
        id: '1',
        type: 'visa',
        last4: '4242',
        expiryMonth: 12,
        expiryYear: 26,
        holder: 'John Doe',
        isDefault: true
      },
      {
        id: '2',
        type: 'mastercard',
        last4: '5555',
        expiryMonth: 09,
        expiryYear: 25,
        holder: 'John Doe',
        isDefault: false
      }
    ]
  };
  
  // Mock wallet address
  const walletAddress = 'okpay_jd_1234567890';
  
  const handleCopyAddress = () => {
    navigator.clipboard.writeText(walletAddress);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
    toast.success('Wallet address copied to clipboard');
  };
  
  const handleAddFunds = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    setIsProcessing(true);
    
    // Simulate API call
    setTimeout(() => {
      toast.success(`Added ${formatCurrency(Number(amount))} to your wallet`);
      setIsProcessing(false);
      setShowAddFunds(false);
      setAmount('');
    }, 1500);
  };
  
  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    if (Number(amount) > wallet.balance) {
      toast.error('Insufficient funds');
      return;
    }
    
    setIsProcessing(true);
    
    // Simulate API call
    setTimeout(() => {
      toast.success(`Withdrawn ${formatCurrency(Number(amount))} from your wallet`);
      setIsProcessing(false);
      setShowWithdraw(false);
      setAmount('');
    }, 1500);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">My Wallet</h1>
        <button className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800">
          <RefreshCw size={16} />
          <span>Refresh</span>
        </button>
      </div>
      
      {/* Wallet Balance */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl shadow-lg p-6 text-white">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <p className="text-blue-100 mb-1">Current Balance</p>
            <h2 className="text-3xl font-bold">{formatCurrency(wallet.balance)}</h2>
            
            <div className="mt-4 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-3 inline-flex items-center gap-3">
              <WalletIcon size={18} />
              <div className="flex items-center gap-2">
                <span className="text-sm">{walletAddress}</span>
                <button 
                  onClick={handleCopyAddress}
                  className="p-1 hover:bg-white/10 rounded-full transition-colors"
                >
                  {isCopied ? <CheckCircle size={16} /> : <Copy size={16} />}
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={() => {
                setShowAddFunds(true);
                setShowWithdraw(false);
              }}
              className="bg-white text-blue-700 font-medium px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-50 transition-colors"
            >
              <PlusCircle size={18} />
              <span>Add Funds</span>
            </button>
            
            <button
              onClick={() => {
                setShowWithdraw(true);
                setShowAddFunds(false);
              }}
              className="bg-blue-500 text-white font-medium px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-600 transition-colors"
            >
              <ArrowDown size={18} />
              <span>Withdraw</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Add Funds Form */}
      {showAddFunds && (
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold mb-4">Add Funds to Wallet</h3>
          
          <form onSubmit={handleAddFunds} className="space-y-4">
            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
                Amount
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <DollarSign size={18} className="text-gray-400" />
                </div>
                <input
                  id="amount"
                  type="text"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  placeholder="0.00"
                  required
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="payment-method" className="block text-sm font-medium text-gray-700 mb-1">
                Payment Method
              </label>
              <select
                id="payment-method"
                className="block w-full py-3 px-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                defaultValue="card1"
              >
                <option value="card1">Visa •••• 4242</option>
                <option value="card2">Mastercard •••• 5555</option>
                <option value="new">Add New Card</option>
              </select>
            </div>
            
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddFunds(false)}
                className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg"
              >
                Cancel
              </button>
              
              <button
                type="submit"
                disabled={isProcessing}
                className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {isProcessing ? 'Processing...' : 'Add Funds'}
              </button>
            </div>
          </form>
        </div>
      )}
      
      {/* Withdraw Form */}
      {showWithdraw && (
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold mb-4">Withdraw Funds</h3>
          
          <form onSubmit={handleWithdraw} className="space-y-4">
            <div>
              <label htmlFor="withdraw-amount" className="block text-sm font-medium text-gray-700 mb-1">
                Amount
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <DollarSign size={18} className="text-gray-400" />
                </div>
                <input
                  id="withdraw-amount"
                  type="text"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  placeholder="0.00"
                  required
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="withdraw-to" className="block text-sm font-medium text-gray-700 mb-1">
                Withdraw To
              </label>
              <select
                id="withdraw-to"
                className="block w-full py-3 px-3 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                defaultValue="card1"
              >
                <option value="bank1">Bank Account (••••1234)</option>
                <option value="card1">Visa •••• 4242</option>
                <option value="card2">Mastercard •••• 5555</option>
                <option value="new">Add New Method</option>
              </select>
            </div>
            
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowWithdraw(false)}
                className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg"
              >
                Cancel
              </button>
              
              <button
                type="submit"
                disabled={isProcessing}
                className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {isProcessing ? 'Processing...' : 'Withdraw'}
              </button>
            </div>
          </form>
        </div>
      )}
      
      {/* Cards */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold">Payment Methods</h3>
          <button className="text-blue-600 text-sm font-medium hover:text-blue-800 flex items-center gap-1">
            <PlusCircle size={16} />
            <span>Add New</span>
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {wallet.cards.map((card) => (
            <WalletCard key={card.id} card={card} />
          ))}
        </div>
      </div>
      
      {/* Transaction Limits */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold mb-4">Transaction Limits</h3>
        
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-700">Daily Withdrawal</p>
              <p className="text-sm font-medium">$2,000 / $5,000</p>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '40%' }}></div>
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-700">Monthly Transfer</p>
              <p className="text-sm font-medium">$8,500 / $20,000</p>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '42.5%' }}></div>
            </div>
          </div>
          
          <p className="text-sm text-gray-500 mt-4">
            Need higher limits? <a href="#" className="text-blue-600 hover:text-blue-800">Verify your identity</a> to upgrade your account.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Wallet;