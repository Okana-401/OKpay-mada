import { Outlet } from 'react-router-dom';
import { Banknote } from 'lucide-react';

const AuthLayout = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col md:flex-row">
      {/* Left side - Branding */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-blue-600 to-indigo-700 text-white p-8 flex-col justify-center items-center">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <Banknote size={40} className="text-white" />
            <h1 className="text-4xl font-bold">OkPay</h1>
          </div>
          <h2 className="text-3xl font-bold mb-6">Welcome to the future of payments</h2>
          <p className="text-xl opacity-80 mb-8">
            Secure, fast, and convenient way to manage your money, send payments, and track your expenses.
          </p>
          
          <div className="grid grid-cols-2 gap-6 mt-12">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
              <h3 className="text-xl font-semibold mb-2">Fast Transfers</h3>
              <p className="opacity-80">Send money instantly to anyone, anywhere.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
              <h3 className="text-xl font-semibold mb-2">Secure Wallet</h3>
              <p className="opacity-80">Your money is protected with top-tier encryption.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
              <h3 className="text-xl font-semibold mb-2">Easy Management</h3>
              <p className="opacity-80">Track all your transactions in one place.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
              <h3 className="text-xl font-semibold mb-2">24/7 Support</h3>
              <p className="opacity-80">Our team is always ready to help you.</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right side - Auth Forms */}
      <div className="w-full md:w-1/2 flex flex-col justify-center items-center p-4 md:p-8">
        <div className="md:hidden flex items-center gap-3 mb-8">
          <Banknote size={32} className="text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-900">OkPay</h1>
        </div>
        <div className="w-full max-w-md">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;